<?php



namespace App\Http\Controllers;

use App\Models\BarriosPropuesta;
use App\Models\cliente;
use App\Models\LineasPropuesta;
use App\Models\logs;
use App\Models\Propuesta;
use Illuminate\Http\Request;
use PhpParser\Node\Stmt\Foreach_;
use Barryvdh\DomPDF\Facade as PDF;
use Exception;
use Illuminate\Support\Facades\DB;

// SDK de Mercado Pago
use MercadoPago;

class PropuestaController extends Controller
{
    
    //
    public function __invoke()
    {
        //return response()->json( $get, 200);
    }

    public  function savepropuesta()
    {
        
        try
        {
            $request = request()->all();
            
            $datos["barriosagregados"] = json_decode( $request["barriosagregados"] );
            $datos["personasaseguradas"] = json_decode( $request["personasaseguradas"] );
            $datos["coberturavigen"] = json_decode( $request["coberturavigen"] );
            $datos["tomador"] = json_decode( $request["tomador"] );
            $datos["parametros"] = json_decode( $request["parametros"] );
        

            $propuesta = new Propuesta();
            $propuesta->prefijo = "O";
            $propuesta->documento = $datos["tomador"]->documento;
            
            $propuesta->nombre = $datos["tomador"]->nombres . " ".$datos["tomador"]->apellidos;
            $propuesta->num_polizas =  count($datos["personasaseguradas"]);
            $propuesta->meses = $datos["coberturavigen"]->meses;
            $propuesta->id_cobertura = $datos["coberturavigen"]->cobertura->nombre;
            $propuesta->fecha_nacimiento = $datos["tomador"]->fechanacimiento;
            $propuesta->nueva_poliza = $propuesta->num_polizas > 1 ? 1 : 2;
            $propuesta->premio = $datos["coberturavigen"]->premio;
            $propuesta->premio_total = $datos["coberturavigen"]->premiototal;
            $propuesta->fechaDesde = $datos["coberturavigen"]->vigenciadesde;
            $propuesta->fechaHasta = $datos["coberturavigen"]->vigenciahasta;
            $propuesta->clausula = count($datos["barriosagregados"]) > 0 ? 1 : 0;
            $propuesta->barrio_beneficiario = 0;
            $propuesta->ultmod = $datos["parametros"]->ultmod;
            $propuesta->useredit = "online";
            $propuesta->codestado = 0;
            $propuesta->cobertura_suma = $datos["coberturavigen"]->cobertura->suma;
            $propuesta->cobertura_deducible = $datos["coberturavigen"]->cobertura->deducible;
            $propuesta->cobertura_gastos = $datos["coberturavigen"]->cobertura->gastos;
            $propuesta->promocion = $datos["coberturavigen"]->promociones;
            $propuesta->paga = 0;
            $propuesta->fecha_paga = $datos["parametros"]->ultmod;
            $propuesta->referencia = null;
            $propuesta->prima = null;
            $propuesta->master = null;
            $propuesta->formadepago = null;
            $propuesta->organizador = null;
            $propuesta->productor = null;
            $propuesta->puntodeventa ="online";
            $propuesta->csrf = $datos["parametros"]->csrf;
            $propuesta->usuariopaga ="ONLINE";

            $cons = DB::table('propuestas')->where('csrf',$datos["parametros"]->csrf)->get();
            if(count($cons) > 0){
                $propuesta->reg = $cons[0]->reg;
                $propuesta->where('csrf',$datos["parametros"]->csrf)->update([

                    "prefijo" => "O",
                    "documento" => $datos["tomador"]->documento,
                    "nombre" => $datos["tomador"]->nombres . " ".$datos["tomador"]->apellidos,
                    "num_polizas" =>  count($datos["personasaseguradas"]),
                    "meses" => $datos["coberturavigen"]->meses,
                    "id_cobertura" => $datos["coberturavigen"]->cobertura->nombre,
                    "nueva_poliza" => $propuesta->num_polizas > 1 ? 1 : 2,
                    "premio" => $datos["coberturavigen"]->premio,
                    "premio_total" => $datos["coberturavigen"]->premiototal,
                    "fechaDesde" => $datos["coberturavigen"]->vigenciadesde,
                    "fechaHasta" => $datos["coberturavigen"]->vigenciahasta,
                    "clausula" => count($datos["barriosagregados"]) > 0 ? 1 : 0,
                    "barrio_beneficiario" => 0,
                    "ultmod" => $datos["parametros"]->ultmod,
                    "useredit" => "online",
                    "codestado" => 0,
                    "cobertura_suma" => $datos["coberturavigen"]->cobertura->suma,
                    "cobertura_deducible" => $datos["coberturavigen"]->cobertura->deducible,
                    "cobertura_gastos" => $datos["coberturavigen"]->cobertura->gastos,
                    "promocion" => $datos["coberturavigen"]->promociones,
                    "paga" => 0,
                    "fecha_paga" => $datos["parametros"]->ultmod,
                    "referencia" => null,
                    "prima" => null,
                    "master" => null,
                    "formadepago" => null,
                    "fecha_nacimiento" => $propuesta->fecha_nacimiento,
                    "organizador" => null,
                    "productor" => null,
                    "puntodeventa" =>"online",
                    "csrf" => $datos["parametros"]->csrf,
                    "usuariopaga" =>"ONLINE"

                ]);

            }else{
                $propuesta->reg = $propuesta->consecutivo();
                $propuesta->id_barrio = $propuesta->reg ;
                $propuesta->save();
            }

                $cliente  = new cliente();
                $cons = $cliente->where('id',$datos["tomador"]->documento)->get();
                if(count($cons) > 0){
                    $cliente->where('id',$datos["tomador"]->documento)->update([
                        "nombres" => $datos["tomador"]->nombres,
                        "apellidos" => $datos["tomador"]->apellidos,
                        "telefono" => $datos["tomador"]->telefono,
                        "direccion" => $datos["tomador"]->direccion,
                        "email" => $datos["tomador"]->email,
                        "ciudad" => $datos["tomador"]->ciudad,
                        "codpostal" => $datos["tomador"]->codpostal,
                        "localidad" => $datos["tomador"]->localidad,
                        "fecha_nacimiento" => $datos["tomador"]->fechanacimiento,
                        "tipo_id" => $datos["tomador"]->tipodocumento,
                        "sexo" => $datos["tomador"]->sexo,
                        "situacion" => $datos["tomador"]->situacionimpositiva,
                        "ultmod" => $datos["parametros"]->ultmod,
                        "user_edit" =>  "online",
                        "categoria" => "ONLINE"
                    ]);
                }else{
                    $cliente->id = $datos["tomador"]->documento;
                    $cliente->nombres = $datos["tomador"]->nombres;
                    $cliente->apellidos = $datos["tomador"]->apellidos;
                    $cliente->telefono = $datos["tomador"]->telefono;
                    $cliente->direccion = $datos["tomador"]->direccion;
                    $cliente->email = $datos["tomador"]->email;
                    $cliente->ciudad = $datos["tomador"]->ciudad;
                    $cliente->codpostal = $datos["tomador"]->codpostal;
                    $cliente->localidad = $datos["tomador"]->localidad;
                    $cliente->fecha_nacimiento = $datos["tomador"]->fechanacimiento;
                    $cliente->tipo_id = $datos["tomador"]->tipodocumento;
                    $cliente->sexo = $datos["tomador"]->sexo;
                    $cliente->situacion = $datos["tomador"]->situacionimpositiva;
                    $cliente->ultmod = $datos["parametros"]->ultmod;
                    $cliente->user_edit = "online";
                    $cliente->categoria = "ONLINE";
                    $cliente->save();
                }
                

                
                

                if (count($datos["personasaseguradas"])> 0) {
                    
                    DB::table('lineas_propuestas')->where('id_propuesta',$propuesta->reg)->where('prefijo',$propuesta->prefijo)->delete();

                    foreach ($datos["personasaseguradas"] as $value) {
                        $lineaspropuestas = new LineasPropuesta();
                        $lineaspropuestas->reg = $propuesta->reg ;
                        $lineaspropuestas->id_propuesta = $propuesta->reg ;
                        $lineaspropuestas->documento = $value->documento;
                        $lineaspropuestas->tipo_documento = $value->tipodocumento;
                        $lineaspropuestas->apellidos = $value->apellidos;
                        $lineaspropuestas->nombres = $value->nombres;
                        $lineaspropuestas->fecha_nacimiento = $value->fechanacimiento;
                        $lineaspropuestas->id_actividad = $value->actividad;
                        $lineaspropuestas->id_clasificacion = $value->clasificacion;
                        $lineaspropuestas->premio = $propuesta->premio;
                        $lineaspropuestas->ultmod = $propuesta->ultmod;
                        $lineaspropuestas->user_edit = $propuesta->useredit;
                        $lineaspropuestas->codestado = 0;
                        $lineaspropuestas->fechaDesde = $propuesta->fechaDesde;
                        $lineaspropuestas->fechaHasta = $propuesta->fechaHasta;
                        $lineaspropuestas->prefijo = $propuesta->prefijo;
                        $lineaspropuestas->actividad = $value->nomactividad;
                        $lineaspropuestas->clasificacion = $value->nomclasificacion;
                        
                        
                        $lineaspropuestas->save();
                    }
                }

        
                
                if ( count($datos["barriosagregados"]) > 0 ) {
                    
                    DB::table('barrios_propuestas')->where('id_propuesta',$propuesta->reg)->where('prefijo',$propuesta->prefijo)->delete();

                    foreach ($datos["barriosagregados"] as $value) {
                        $barriospropuestas = new BarriosPropuesta();
                        $barriospropuestas->reg = $propuesta->reg;
                        $barriospropuestas->id_propuesta = $propuesta->reg;
                        $barriospropuestas->id_barrio = $value->cuit;
                        $barriospropuestas->nombre = $value->nombre;
                        $barriospropuestas->ultmod = $propuesta->ultmod;
                        $barriospropuestas->user_edit = $propuesta->useredit;
                        $barriospropuestas->codestado = 1;
                        $barriospropuestas->prefijo = $propuesta->prefijo;
                        $barriospropuestas->save(); 
                        
                    }
                }

                // Agrega credenciales
                MercadoPago\SDK::setAccessToken(config('services.mercadopago.token'));
                // Crea un objeto de preferencia
                $preference = new MercadoPago\Preference();

                // Crea un ítem en la preferencia
                $item = new MercadoPago\Item();
                $item->title = "Póliza No. ".$propuesta->prefijo."-".$propuesta->reg." | "."Tomador : ".$propuesta->nombre;
                $item->quantity = 1;
                $item->unit_price = $propuesta->premio_total;

                $preference->back_urls = array(
                    "success" => url('/polizas')."?estado=success&idpropuesta=".$propuesta->reg."&prefijo=".$propuesta->prefijo,
                    "failure" => url('/cotizadoronline')."?estado=failure",
                    "pending" => url('/polizas')."?estado=pending&idpropuesta=".$propuesta->reg."&prefijo=".$propuesta->prefijo
                );

                $preference->items = array($item);
                $preference->save();
                
                //total=590&idpropuesta=2&prefijo=O&tomador=MARIO%20LASLUISA%20CASTAÑO
            
                return response()->json(
                    [
                        'res' => 'Se ha generado la propuesta con éxito', 'success'=>true, 
                        'idpropuesta' => $propuesta->reg,
                        'prefijo' => $propuesta->prefijo,
                        'total' => $propuesta->premio_total,
                        'tomador' => $propuesta->nombre,
                        'preference' => $preference->id

                    ], 202);

        }catch(Exception $ex){
            $logs = new logs();
            $logs->saveerror($ex->getMessage(), $propuesta->reg, $propuesta->prefijo, "101");
            return response()->json(['res' => 'No se ha podido guardar la propuesta error #101', 'success'=>false], 400);
        }

        
    }


    public function paypropuesta()
    {
        $data = request()->all();
        return view('pay.index', compact('data'));
    }


    public function descargapdfpoliza()
    {
        $data = request()->all();

        $data = DB::table('propuestas')->where('reg',$data['id'])->where('prefijo', $data['prefijo'])->get();
        
        
        if (count($data) > 0) {

        $lineasdata = DB::table('lineas_propuestas')->where('id_propuesta',$data[0]->reg)->where('prefijo',$data[0]->prefijo)->get();
        $barriospropuesta = DB::table('barrios_propuestas')->where('id_propuesta',$data[0]->reg)->where('prefijo',$data[0]->prefijo)->get();

        $cliente = DB::table('clientes')->where('id',$data[0]->documento)->get();
        
            $pdf = PDF::loadView('pdf-propuesta.index', compact('cliente','data','lineasdata','barriospropuesta'));
            return $pdf->stream();
        } else {
            return response()->json(['res' => 'El documento solicitado no existe o no se ha generado en la nube'], 400);
        }
    }


    public function cotizadoronline()
    {
        $data["coberturas"] = DB::table('coberturas')->where('codestado','=', '1')->get();
        $data["actividades"] = DB::table('actividades')->where('codestado','=', '1')->get();
        $data["clasificaciones"] = DB::table('clasificaciones')->where('codestado','=', '1')->get();
        $data["provincias"] = DB::table('provincias')->where('codestado','=', '1')->get();
        $data["barrios"] = DB::table('barrios')->where('codestado','=', '1')->get();
        $data["gruposbarrios"] = DB::table('gruposbarrios')->get();
        $data["gruposbarriosnombres"] = DB::table('gruposbarrios')->select('nombre','id')->distinct()->get();

        /*MercadoPago\SDK::setAccessToken('PROD_ACCESS_TOKEN');
        $preference = new MercadoPago\Preference();
        // Create a preference item
        $item = new MercadoPago\Item();
        $item->title = 'My Item';
        $item->quantity = 1;
        $item->unit_price = 75;
        $preference->items = array($item);
        $preference->save();*/

        return view('cotizadoronline.index', compact('data'));
        
    }


    public function polizas()
    {
        $data = [];
        $success = true;
        $estado = "";
        $req = request()->all();
        if($req){
            $prop = new Propuesta();
            $estado = request()->get('estado');
            if($estado == "success"){
                $prop->pagarpropuesta($req["idpropuesta"],$req["prefijo"],$req["payment_type"],$req["payment_id"]);
            }
        }
        return view('polizas.index', compact('data','success','estado'));
    }

    

    public function consultapoliza()
    {
        $data = request()->all();
        $estado = "";

        //$data = DB::table('lineas_propuestas')->where('fechaHasta','>=', date("Y-m-d H:i:s"))->where('tipo_documento', $data['tipodocumento'])->where('documento', $data['documento'])->where('codestado','>','0')->get();

        


        $data = DB::table('lineas_propuestas')->join('propuestas', function ($join) {
            $join->on('lineas_propuestas.id_propuesta', '=', 'propuestas.reg');
        })->where('lineas_propuestas.fechaHasta','>=', date("Y-m-d H:i:s"))->where('lineas_propuestas.fecha_nacimiento','=', $data['fechanacimiento'])->where('lineas_propuestas.codestado','>','0')->where('lineas_propuestas.tipo_documento', $data['tipodocumento'])->where('lineas_propuestas.documento', $data['documento'])->orWhere('propuestas.documento', $data['documento'])->where('propuestas.fecha_nacimiento','=', $data['fechanacimiento'])
        ->select('lineas_propuestas.*')->groupBy('propuestas.id')
        ->get();

        //$data = DB::select("SELECT t1.* FROM lineas_propuestas t1 INNER JOIN propuestas t2 ON t1.id_propuesta = t2.reg WHERE t1.documento = '".$data['documento']."' OR t2.documento = '".$data['documento']."' GROUP BY t1.id_propuesta");

        $success = false;        

        if (count($data) > 0) {
            $success = true;
            //return response()->json($data, 200);
            return view('polizas.index', compact('data','success','estado'));
        } else {
            return view('polizas.index', compact('data','success','estado'));
        }
    }

    public function consultaparametros()
    {
        $req = request()->all();
        $datos = [];

        if($req["rolpuntodeventa"] == "COLABORADOR"){

            $datos["actividades"] = DB::table('actividades')->where('ultmod','>=',$req["fecha_actualizacion_desde"])->where('ultmod','<=',$req["fecha_actualizacion_hasta"])->get();
            $datos["coberturas"] = DB::table('coberturas')->where('ultmod','>=',$req["fecha_actualizacion_desde"])->where('ultmod','<=',$req["fecha_actualizacion_hasta"])->get();
            $datos["clasificaciones"] = DB::table('clasificaciones')->where('ultmod','>=',$req["fecha_actualizacion_desde"])->where('ultmod','<=',$req["fecha_actualizacion_hasta"])->get();

        }

        if($req["rolpuntodeventa"] == "PRINCIPAL"){
            $datos["propuestas"] = DB::table('propuestas')->where('ultmod','>=',$req["fecha_actualizacion_desde"])->where('ultmod','<=',$req["fecha_actualizacion_hasta"])->where('prefijo','=','O')->get();
            
            $datos["lineas_propuestas"] = DB::table('lineas_propuestas')->where('ultmod','>=',$req["fecha_actualizacion_desde"])->where('ultmod','<=',$req["fecha_actualizacion_hasta"])->where('prefijo','=','O')->get();

            $datos["barrios_propuestas"] = DB::table('barrios_propuestas')->where('ultmod','>=',$req["fecha_actualizacion_desde"])->where('ultmod','<=',$req["fecha_actualizacion_hasta"])->where('prefijo','=','O')->get();

            $datos["clientes"] = DB::table('clientes')->where('ultmod','>=',$req["fecha_actualizacion_desde"])->where('ultmod','<=',$req["fecha_actualizacion_hasta"])->get();
        }

        return response()->json($datos, 200);
        
    }
}

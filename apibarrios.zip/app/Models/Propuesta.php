<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Propuesta extends Model
{
    use HasFactory;

    public function consecutivo(){
        
        $cons = DB::table('propuestas')->where('prefijo','O')->orderBy('reg','DESC')->limit(1)->get();
        if(count($cons) > 0)
            return $cons[0]->reg + 1;
        else
            return 1;
    }

    public function pagarpropuesta($idpropuesta, $prefijo,$formadepago,$idpago){

        $propuesta = new Propuesta();

        $propuesta->where('reg',$idpropuesta)->where('prefijo',$prefijo)->update([
            "codestado" => 1,
            "paga" => 1,
            "csrf" => null,
            "fecha_paga" => date("Y-m-d H:i:s"),
            "tipopago" => $formadepago,
            "compformadepago" => $idpago
        ]);

        $lineapropuesta = new LineasPropuesta();

        $lineapropuesta->where('id_propuesta',$idpropuesta)->where('prefijo',$prefijo)->update([
            "codestado" => 1
        ]);
    }
}
